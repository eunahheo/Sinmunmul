CREATE TABLE `user` (
  `user_seq` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(30) DEFAULT NULL,
  `user_pwd` varchar(100) NOT NULL,
  `user_gender` varchar(10) DEFAULT NULL,
  `user_age` int DEFAULT NULL,
  `user_sgtype` varchar(20) DEFAULT NULL,
  `del_yn` varchar(1) DEFAULT 'n',
  `reg_dt` varchar(20) DEFAULT NULL,
  `reg_id` varchar(30) DEFAULT NULL,
  `mod_dt` varchar(20) DEFAULT NULL,
  `mod_id` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user_seq`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `common_code_group` (
  `code_group_seq` int NOT NULL AUTO_INCREMENT,
  `code_group` int NOT NULL,
  `cg_value` varchar(20) NOT NULL,
  `cg_order` int NOT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(30) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(30) NOT NULL,
  PRIMARY KEY (`code_group_seq`),
  UNIQUE KEY `code_group_UNIQUE` (`code_group`)
) ENGINE=InnoDB AUTO_INCREMENT=23433 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `common_code` (
  `code_seq` int NOT NULL AUTO_INCREMENT,
  `code_group` int NOT NULL,
  `code` int NOT NULL,
  `value` varchar(20) DEFAULT NULL,
  `code_order` int DEFAULT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(30) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(30) NOT NULL,
  PRIMARY KEY (`code_seq`),
  UNIQUE KEY `code_UNIQUE` (`code`),
  KEY `FK_Common_code_group_TO_Common_code_idx` (`code_group`),
  CONSTRAINT `FK_Common_code_TO_Common_code_group` FOREIGN KEY (`code_group`) REFERENCES `common_code_group` (`code_group`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `interest` (
  `interest_seq` int NOT NULL AUTO_INCREMENT,
  `user_seq` int NOT NULL,
  `code_group` int DEFAULT NULL,
  `code` int NOT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(30) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(30) NOT NULL,
  PRIMARY KEY (`interest_seq`),
  KEY `FK_User_TO_Interest` (`user_seq`),
  KEY `FK_Common_code_group_TO_Interest` (`code_group`),
  KEY `FK_Common_code_TO_Interest` (`code`),
  CONSTRAINT `FK_Common_code_group_TO_Interest` FOREIGN KEY (`code_group`) REFERENCES `common_code_group` (`code_group`),
  CONSTRAINT `FK_Common_code_TO_Interest` FOREIGN KEY (`code`) REFERENCES `common_code` (`code`),
  CONSTRAINT `FK_User_TO_Interest` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=2278 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `news` (
  `news_seq` bigint NOT NULL AUTO_INCREMENT,
  `news_title` varchar(500) DEFAULT NULL,
  `news_link` varchar(500) DEFAULT NULL,
  `news_press` varchar(50) DEFAULT NULL,
  `news_author` varchar(50) DEFAULT NULL,
  `news_author_email` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `news_desc` varchar(10000) DEFAULT NULL,
  `news_summary` varchar(500) NOT NULL,
  `news_reg_dt` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `news_mod_dt` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `news_photo` varchar(500) DEFAULT NULL,
  `code_group` int DEFAULT NULL,
  `code` int DEFAULT NULL,
  `news_positive` decimal(13,10) DEFAULT '0.0000000000',
  `news_negative` decimal(13,10) DEFAULT '0.0000000000',
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(30) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(30) NOT NULL,
  PRIMARY KEY (`news_seq`),
  KEY `FK_News_TO_Common_code_group_idx` (`code_group`),
  KEY `FK_News_TO_Common_code_idx` (`code`),
  KEY `index_news_reg_dt` (`news_reg_dt` DESC),
  KEY `index_news_title_g` (`news_title`),
  FULLTEXT KEY `index_news_desc` (`news_desc`),
  FULLTEXT KEY `index_news_title` (`news_title`),
  FULLTEXT KEY `index_news_title_desc` (`news_title`,`news_desc`),
  CONSTRAINT `FK_News_TO_Common_code` FOREIGN KEY (`code`) REFERENCES `common_code` (`code`),
  CONSTRAINT `FK_News_TO_Common_code_group` FOREIGN KEY (`code_group`) REFERENCES `common_code_group` (`code_group`)
) ENGINE=InnoDB AUTO_INCREMENT=367449 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `news_recommend` (
  `recom_seq` bigint NOT NULL AUTO_INCREMENT,
  `code` int DEFAULT NULL,
  `news_seq` bigint DEFAULT NULL,
  `keyword1` varchar(30) DEFAULT NULL,
  `keyword2` varchar(30) DEFAULT NULL,
  `keyword3` varchar(30) DEFAULT NULL,
  `del_yn` varchar(1) DEFAULT NULL,
  `reg_dt` varchar(20) DEFAULT NULL,
  `reg_id` varchar(30) DEFAULT NULL,
  `mod_dt` varchar(20) DEFAULT NULL,
  `mod_id` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`recom_seq`),
  UNIQUE KEY `news_seq_UNIQUE` (`news_seq`),
  KEY `FK_news_recommend_TO_common_code_idx` (`code`),
  KEY `FK_news_recommend_TO_news_idx` (`news_seq`),
  CONSTRAINT `FK_news_recommend_TO_common_code` FOREIGN KEY (`code`) REFERENCES `common_code` (`code`),
  CONSTRAINT `FK_news_recommend_TO_news` FOREIGN KEY (`news_seq`) REFERENCES `news` (`news_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=140706 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `news_topic` (
  `topic_seq` bigint NOT NULL AUTO_INCREMENT,
  `code` int DEFAULT NULL,
  `keyword` varchar(50) DEFAULT NULL,
  `del_yn` varchar(1) DEFAULT 'n',
  `reg_dt` varchar(20) DEFAULT NULL,
  `reg_id` varchar(30) DEFAULT NULL,
  `mod_dt` varchar(20) DEFAULT NULL,
  `mod_id` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`topic_seq`),
  KEY `FK_news_topic_TO_common_code_idx` (`code`),
  CONSTRAINT `FK_news_topic_TO_common_code` FOREIGN KEY (`code`) REFERENCES `common_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=1090 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `news_wordcloud` (
  `wordcloud_seq` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code_group` int DEFAULT NULL,
  `wordcloud` json NOT NULL,
  `del_yn` varchar(1) DEFAULT 'n',
  `reg_dt` varchar(20) DEFAULT NULL,
  `reg_id` varchar(30) DEFAULT NULL,
  `mod_dt` varchar(20) DEFAULT NULL,
  `mod_id` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`wordcloud_seq`),
  UNIQUE KEY `wordcloud_seq_UNIQUE` (`wordcloud_seq`),
  KEY `FK_news_wordcloud_TO_Common_code_group_idx` (`code_group`),
  CONSTRAINT `FK_news_wordcloud_TO_Common_code_group` FOREIGN KEY (`code_group`) REFERENCES `common_code_group` (`code_group`)
) ENGINE=InnoDB AUTO_INCREMENT=669 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `scrap` (
  `scrap_seq` int NOT NULL AUTO_INCREMENT,
  `user_seq` int NOT NULL,
  `news_seq` bigint NOT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(30) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(30) NOT NULL,
  PRIMARY KEY (`scrap_seq`),
  KEY `FK_User_TO_Scrap_1` (`user_seq`),
  KEY `FK_News_TO_Scrap_1` (`news_seq`),
  CONSTRAINT `FK_News_TO_Scrap_1` FOREIGN KEY (`news_seq`) REFERENCES `news` (`news_seq`),
  CONSTRAINT `FK_User_TO_Scrap_1` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
